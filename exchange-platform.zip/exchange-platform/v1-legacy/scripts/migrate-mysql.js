const mysql = require('mysql2/promise');
require('dotenv').config();

async function createMySQLTables() {
    console.log('🗄️ Creating MySQL Multi-Tenant Schema for InfinityFree...');

    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    try {
        // Platform-level tables (shared)
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS tenants (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id VARCHAR(50) UNIQUE NOT NULL,
                name VARCHAR(255) NOT NULL,
                subdomain VARCHAR(100) UNIQUE,
                plan VARCHAR(50) NOT NULL DEFAULT 'basic',
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                admin_email VARCHAR(255) NOT NULL,
                admin_phone VARCHAR(20),
                exchange_address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approved_at TIMESTAMP NULL,
                expires_at TIMESTAMP NULL,
                settings JSON
            )
        `);

        await connection.execute(`
            CREATE TABLE IF NOT EXISTS platform_users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(50) NOT NULL DEFAULT 'super_admin',
                tenant_id VARCHAR(50),
                name VARCHAR(255) NOT NULL,
                phone VARCHAR(20),
                status VARCHAR(20) NOT NULL DEFAULT 'active',
                last_login TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                settings JSON,
                FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id) ON DELETE CASCADE
            )
        `);

        // Tenant-specific tables (isolated per tenant)
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS tenant_users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id VARCHAR(50) NOT NULL,
                email VARCHAR(255) NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                name VARCHAR(255) NOT NULL,
                role VARCHAR(50) NOT NULL DEFAULT 'customer',
                phone VARCHAR(20),
                status VARCHAR(20) NOT NULL DEFAULT 'active',
                p2p_enabled BOOLEAN DEFAULT FALSE,
                kyc_status VARCHAR(20) DEFAULT 'pending',
                balance DECIMAL(15,2) DEFAULT 0.00,
                last_login TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                settings JSON,
                UNIQUE KEY unique_tenant_email (tenant_id, email)
            )
        `);

        await connection.execute(`
            CREATE TABLE IF NOT EXISTS tenant_transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id VARCHAR(50) NOT NULL,
                user_id INT,
                type VARCHAR(50) NOT NULL,
                amount DECIMAL(15,2) NOT NULL,
                currency VARCHAR(10) NOT NULL DEFAULT 'USD',
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                description TEXT,
                reference_id VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP NULL,
                FOREIGN KEY (user_id) REFERENCES tenant_users(id) ON DELETE CASCADE
            )
        `);

        await connection.execute(`
            CREATE TABLE IF NOT EXISTS p2p_trades (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tenant_id VARCHAR(50),
                buyer_id INT,
                seller_id INT,
                amount DECIMAL(15,2) NOT NULL,
                rate DECIMAL(10,4) NOT NULL,
                currency_from VARCHAR(10) NOT NULL,
                currency_to VARCHAR(10) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                type VARCHAR(20) NOT NULL DEFAULT 'customer_p2p',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP NULL,
                FOREIGN KEY (buyer_id) REFERENCES tenant_users(id) ON DELETE CASCADE,
                FOREIGN KEY (seller_id) REFERENCES tenant_users(id) ON DELETE CASCADE
            )
        `);

        await connection.execute(`
            CREATE TABLE IF NOT EXISTS exchanger_p2p (
                id INT AUTO_INCREMENT PRIMARY KEY,
                from_tenant_id VARCHAR(50) NOT NULL,
                to_tenant_id VARCHAR(50) NOT NULL,
                amount DECIMAL(15,2) NOT NULL,
                rate DECIMAL(10,4) NOT NULL,
                currency VARCHAR(10) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP NULL
            )
        `);

        // Create indexes for performance
        await connection.execute('CREATE INDEX IF NOT EXISTS idx_tenant_users_tenant_id ON tenant_users(tenant_id)');
        await connection.execute('CREATE INDEX IF NOT EXISTS idx_tenant_transactions_tenant_id ON tenant_transactions(tenant_id)');
        await connection.execute('CREATE INDEX IF NOT EXISTS idx_p2p_trades_tenant_id ON p2p_trades(tenant_id)');

        console.log('✅ MySQL database schema created successfully!');
        console.log('📊 Tables created for InfinityFree:');
        console.log('   🏢 tenants - Tenant registration and management');
        console.log('   👑 platform_users - Super Admin and platform users');
        console.log('   👥 tenant_users - Exchange users (isolated per tenant)');
        console.log('   💰 tenant_transactions - Financial transactions');
        console.log('   🤝 p2p_trades - Customer P2P trades');
        console.log('   🏢 exchanger_p2p - Inter-exchanger trading');

    } catch (error) {
        console.error('❌ MySQL migration failed:', error);
        throw error;
    } finally {
        await connection.end();
    }
}

createMySQLTables().catch(console.error);