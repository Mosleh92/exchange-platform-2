
// Simple Working Auth System
console.log('🔐 Auth.js loading...');

// Define current user
window.currentUser = {
    name: 'Exchanger Admin',
    email: 'admin@exchange.com',
    role: 'exchanger_admin',
    permissions: {
        dashboard: true,
        tenant_management: true,
        p2p: true,
        crypto: true,
        calculator: true,
        hawala: true,
        reports: true,
        customers: true
    }
};

// Check permissions function
window.hasPermission = function(permission) {
    return window.currentUser?.permissions?.[permission] === true;
};

// Show notification function
window.showNotification = function(message, type = 'info') {
    console.log(`📢 ${type.toUpperCase()}: ${message}`);
    
    const colors = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        warning: 'bg-yellow-500',
        info: 'bg-blue-500'
    };
    
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 16px;
        border-radius: 8px;
        color: white;
        z-index: 9999;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    `;
    notification.className = colors[type] || colors.info;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 3000);
};

console.log('✅ Auth.js loaded successfully!', window.currentUser);
AUTH_NEW_END