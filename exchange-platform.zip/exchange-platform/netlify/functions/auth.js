// netlify/functions/auth.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { getDatabase } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { email, password, user_type = 'platform', tenant_id } = JSON.parse(event.body);
    
    // استفاده از کد موجود server-sqlite.js
    const db = await getDatabase();
    
    let query, params;
    if (user_type === 'tenant' && tenant_id) {
      query = 'SELECT * FROM tenant_users WHERE email = ? AND tenant_id = ?';
      params = [email, tenant_id];
    } else {
      query = 'SELECT * FROM platform_users WHERE email = ?';
      params = [email];
    }

    const user = await new Promise((resolve, reject) => {
      db.get(query, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!user || !await bcrypt.compare(password, user.password_hash)) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Invalid credentials' })
      };
    }

    // Update last login
    await new Promise((resolve, reject) => {
      db.run('UPDATE platform_users SET last_login = datetime("now") WHERE id = ?', [user.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    const token = jwt.sign(
      { 
        userId: user.id, 
        email: user.email, 
        role: user.role,
        tenantId: user.tenant_id,
        userType: user_type
      },
      process.env.JWT_SECRET || 'ExchangePlatform2024SecretKey',
      { expiresIn: '24h' }
    );

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          tenantId: user.tenant_id,
          userType: user_type
        }
      })
    };

  } catch (error) {
    console.error('Auth error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Authentication failed' })
    };
  }
};