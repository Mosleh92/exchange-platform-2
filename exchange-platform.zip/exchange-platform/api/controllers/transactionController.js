const Transaction = require('../models/Transaction');

// ثبت معامله جدید
exports.createTransaction = async (req, res) => {
  try {
    const { type, currency, amount, rate, customer, description } = req.body;
    const profit = (type === 'sell') ? (amount * rate) * 0.01 : 0; // مثال محاسبه سود
    const transaction = new Transaction({
      tenantId: req.tenantId,
      type, currency, amount, rate, profit, customer, description
    });
    await transaction.save();
    res.status(201).json(transaction);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// لیست معاملات با فیلتر
exports.getTransactions = async (req, res) => {
  try {
    const txs = await Transaction.find({ tenantId: req.tenantId }).populate('customer');
    res.json(txs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};