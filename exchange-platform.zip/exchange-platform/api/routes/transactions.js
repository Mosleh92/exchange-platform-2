import express from 'express';
import { createTransaction, getTransactions } from '../controllers/transactionController.js';
import auth from '../middlewares/auth.js';
import tenant from '../middlewares/tenant.js';

const router = express.Router();
router.use(auth);
router.use(tenant);

router.post('/', createTransaction);
router.get('/', getTransactions);

export default router;