module.exports = (req, res, next) => {
  // فرض: tenantId از توکن یا session می‌آید
  req.tenantId = req.user.tenantId;
  next();
};