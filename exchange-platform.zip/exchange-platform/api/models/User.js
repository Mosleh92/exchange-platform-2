const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
  tenantId: { type: String, required: true },
  username: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['owner', 'admin', 'employee', 'customer'], required: true },
  branches: [{ type: mongoose.Schema.Types.ObjectId, ref: "Branch" }]
});
module.exports = mongoose.model('User', userSchema);