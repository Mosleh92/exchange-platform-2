const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  tenantId: { type: String, required: true }, // جداکننده هر صرافی
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
  type: { type: String, enum: ['buy', 'sell', 'cash', 'transfer'], required: true },
  currency: { type: String, required: true },
  amount: { type: Number, required: true },
  rate: { type: Number, required: true },
  profit: { type: Number },
  date: { type: Date, default: Date.now },
  description: { type: String }
});

module.exports = mongoose.model('Transaction', transactionSchema);