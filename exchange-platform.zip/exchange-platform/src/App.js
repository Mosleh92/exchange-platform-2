const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { createServer } = require('http');
const { Server } = require('socket.io');
const cron = require('node-cron');
require('dotenv').config();

const logger = require('./utils/logger');
const { errorHandler, notFound } = require('./middleware/errorHandler');
const { connectRedis } = require('./config/redis');
const { seedDefaultData } = require('./scripts/seedDatabase');

// Import routes
const authRoutes = require('./routes/auth.routes');
const tenantRoutes = require('./routes/tenant.routes');
const transactionRoutes = require('./routes/transaction.routes');
const customerRoutes = require('./routes/customer.routes');
const rateRoutes = require('./routes/exchangeRate.routes');
const reportRoutes = require('./routes/report.routes');
const accountingRoutes = require('./routes/accounting.routes');
const notificationRoutes = require('./routes/notification.routes');
const settingsRoutes = require('./routes/settings.routes');
const backupRoutes = require('./routes/backup.routes');

// Import services
const ExchangeRateService = require('./services/exchangeRateService');
const NotificationService = require('./services/notificationService');
const BackupService = require('./services/backupService');

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.NODE_ENV === 'production' 
      ? process.env.FRONTEND_URLS?.split(',') || []
      : ['http://localhost:3000', 'http://localhost:8080'],
    methods: ['GET', 'POST']
  }
});

// Security middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdn.tailwindcss.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https:", "wss:"]
    }
  }
}));

app.use(compression());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'production' ? 100 : 1000,
  message: { 
    error: 'Too many requests from this IP',
    code: 'RATE_LIMIT_EXCEEDED',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false
});

app.use('/api/', limiter);

// Enhanced CORS
app.use(cors({
  origin: function (origin, callback) {
    const allowedOrigins = process.env.NODE_ENV === 'production'
      ? (process.env.FRONTEND_URLS?.split(',') || [])
      : ['http://localhost:3000', 'http://localhost:8080', 'http://127.0.0.1:8080'];
    
    if (!origin || allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Tenant-ID', 'X-Requested-With']
}));

// Body parsing with enhanced limits
app.use(express.json({ 
  limit: '10mb',
  verify: (req, res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`, {
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    tenantId: req.headers['x-tenant-id']
  });
  next();
});

// Health check with detailed info
app.get('/api/health', async (req, res) => {
  try {
    const mongoStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
    const redisStatus = await checkRedisHealth();
    
    res.json({ 
      status: 'healthy',
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: require('../package.json').version,
      services: {
        mongodb: mongoStatus,
        redis: redisStatus,
        exchangeRates: 'active',
        notifications: 'active'
      },
      memory: {
        used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + ' MB',
        total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024) + ' MB'
      }
    });
  } catch (error) {
    res.status(503).json({
      status: 'unhealthy',
      error: error.message
    });
  }
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/tenants', tenantRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/rates', rateRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/accounting', accountingRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/backup', backupRoutes);

// Socket.IO for real-time features
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  const tenantId = socket.handshake.auth.tenantId;
  
  if (token && tenantId) {
    // TODO: Verify JWT token
    socket.tenantId = tenantId;
    next();
  } else {
    next(new Error('Authentication error'));
  }
});

io.on('connection', (socket) => {
  logger.info(`Client connected: ${socket.id} for tenant: ${socket.tenantId}`);
  
  // Join tenant room
  socket.join(`tenant_${socket.tenantId}`);
  
  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
});

// Make io available to routes
app.set('io', io);

// Scheduled jobs
if (process.env.NODE_ENV === 'production') {
  // Update exchange rates every 5 minutes
  cron.schedule('*/5 * * * *', async () => {
    try {
      await ExchangeRateService.updateAllTenantsRates();
      logger.info('✅ Exchange rates updated successfully');
    } catch (error) {
      logger.error('❌ Failed to update exchange rates:', error);
    }
  });

  // Daily backup at 2 AM
  cron.schedule('0 2 * * *', async () => {
    try {
      await BackupService.performDailyBackup();
      logger.info('✅ Daily backup completed');
    } catch (error) {
      logger.error('❌ Daily backup failed:', error);
    }
  });

  // Send daily reports at 6 AM
  cron.schedule('0 6 * * *', async () => {
    try {
      await NotificationService.sendDailyReports();
      logger.info('✅ Daily reports sent');
    } catch (error) {
      logger.error('❌ Failed to send daily reports:', error);
    }
  });
}

// Error handling
app.use(notFound);
app.use(errorHandler);

// Database connections
async function connectDatabases() {
  try {
    // MongoDB connection
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });
    logger.info('✅ Connected to MongoDB');

    // Redis connection (for caching and sessions)
    if (process.env.REDIS_URL) {
      await connectRedis();
      logger.info('✅ Connected to Redis');
    }

    // Seed default data
    await seedDefaultData();

  } catch (error) {
    logger.error('❌ Database connection error:', error);
    process.exit(1);
  }
}

async function checkRedisHealth() {
  // Implementation for Redis health check
  return 'connected'; // Simplified
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => {
    mongoose.connection.close();
    process.exit(0);
  });
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

// Start server
const PORT = process.env.PORT || 5000;
server.listen(PORT, async () => {
  await connectDatabases();
  
  logger.info(`🚀 Exchange SaaS Backend v${require('../package.json').version} running on port ${PORT}`);
  logger.info(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`🔗 Health check: http://localhost:${PORT}/api/health`);
  logger.info(`📊 Socket.IO enabled for real-time features`);
});

module.exports = { app, server, io };