const jwt = require('jsonwebtoken');
const Tenant = require('../models/Tenant');
const { connectTenantDB, getTenantDBConnection } = require('../utils/multiTenant');
const logger = require('../utils/logger');
const redis = require('../config/redis');

const tenantIsolation = async (req, res, next) => {
  try {
    // Extract JWT token
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ 
        error: 'Access token required',
        code: 'TOKEN_MISSING'
      });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Extract tenant ID
    const tenantId = req.headers['x-tenant-id'] || decoded.tenantId || req.query.tenant;
    
    if (!tenantId) {
      return res.status(403).json({
        error: 'Tenant access required',
        code: 'NO_TENANT_ACCESS'
      });
    }

    // Check Redis cache first
    let tenant = null;
    if (redis.client) {
      const cachedTenant = await redis.client.get(`tenant:${tenantId}`);
      if (cachedTenant) {
        tenant = JSON.parse(cachedTenant);
      }
    }

    // If not in cache, get from database
    if (!tenant) {
      tenant = await Tenant.findOne({ 
        tenant_id: tenantId, 
        status: 'active' 
      }).lean();

      if (!tenant) {
        return res.status(404).json({
          error: 'Tenant not found or inactive',
          code: 'TENANT_NOT_FOUND'
        });
      }

      // Cache for 15 minutes
      if (redis.client) {
        await redis.client.setex(`tenant:${tenantId}`, 900, JSON.stringify(tenant));
      }
    }

    // Check subscription status
    const now = new Date();
    if (tenant.subscription_expires_at && new Date(tenant.subscription_expires_at) < now) {
      return res.status(403).json({
        error: 'Tenant subscription expired',
        code: 'TENANT_EXPIRED',
        expires_at: tenant.subscription_expires_at
      });
    }

    // Check feature permissions
    const userRole = decoded.role || 'user';
    const requiredPermission = getRequiredPermission(req.route?.path, req.method);
    
    if (!hasPermission(tenant.permissions, userRole, requiredPermission)) {
      return res.status(403).json({
        error: 'Insufficient permissions',
        code: 'PERMISSION_DENIED',
        required: requiredPermission
      });
    }

    // Connect to tenant-specific database
    let tenantDB;
    try {
      tenantDB = await getTenantDBConnection(tenant.database_name);
    } catch (dbError) {
      logger.error(`Failed to connect to tenant DB ${tenant.database_name}:`, dbError);
      return res.status(500).json({
        error: 'Tenant database unavailable',
        code: 'TENANT_DB_ERROR'
      });
    }

    // Attach to request
    req.user = {
      ...decoded,
      permissions: getUserPermissions(tenant.permissions, userRole)
    };
    
    req.tenant = {
      id: tenantId,
      name: tenant.name,
      db: tenantDB,
      settings: tenant.settings || {},
      subscription: {
        plan: tenant.subscription_plan,
        expires_at: tenant.subscription_expires_at,
        features: tenant.enabled_features || []
      },
      limits: tenant.limits || {}
    };

    // Log access
    logger.info(`Tenant access granted`, {
      tenantId,
      userId: decoded.userId,
      role: userRole,
      endpoint: `${req.method} ${req.originalUrl}`,
      ip: req.ip
    });

    // Update last activity
    await updateTenantLastActivity(tenantId);

    next();

  } catch (error) {
    logger.error('Tenant isolation error:', error);
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(403).json({
        error: 'Invalid token',
        code: 'TOKEN_INVALID'
      });
    }

    if (error.name === 'TokenExpiredError') {
      return res.status(403).json({
        error: 'Token expired',
        code: 'TOKEN_EXPIRED'
      });
    }

    res.status(500).json({
      error: 'Tenant access failed',
      code: 'TENANT_ACCESS_ERROR'
    });
  }
};

function getRequiredPermission(path, method) {
  const permissionMap = {
    'GET /transactions': 'transactions.read',
    'POST /transactions': 'transactions.create',
    'PUT /transactions': 'transactions.update',
    'DELETE /transactions': 'transactions.delete',
    'GET /reports': 'reports.read',
    'GET /accounting': 'accounting.read',
    'POST /accounting': 'accounting.create',
    'GET /settings': 'settings.read',
    'PUT /settings': 'settings.update'
  };

  return permissionMap[`${method} ${path}`] || 'basic.access';
}

function hasPermission(tenantPermissions, userRole, requiredPermission) {
  const rolePermissions = tenantPermissions?.[userRole] || [];
  return rolePermissions.includes(requiredPermission) || rolePermissions.includes('*');
}

function getUserPermissions(tenantPermissions, userRole) {
  return tenantPermissions?.[userRole] || [];
}

async function updateTenantLastActivity(tenantId) {
  try {
    await Tenant.updateOne(
      { tenant_id: tenantId },
      { 
        last_activity: new Date(),
        $inc: { request_count: 1 }
      }
    );
  } catch (error) {
    logger.warn('Failed to update tenant activity:', error);
  }
}

module.exports = tenantIsolation;