// src/controllers/transaction.controller.js
const { validationResult } = require('express-validator');
const mongoose = require('mongoose');
const moment = require('moment-jalaali');
const logger = require('../utils/logger');
const { generateReference, formatCurrency } = require('../utils/helpers');

class TransactionController {
  // ایجاد معامله خرید
  async createBuyTransaction(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const tenantDB = req.tenant.db;
      const {
        customer_id,
        currency_from,
        currency_to = 'IRR',
        amount_from,
        payment_method = 'cash',
        notes = '',
        custom_rate = null,
        receipt_number = null
      } = req.body;

      // بررسی مشتری
      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(customer_id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      // دریافت نرخ ارز
      let exchange_rate;
      if (custom_rate && req.user.permissions?.includes('rates.custom')) {
        exchange_rate = parseFloat(custom_rate);
      } else {
        const rates = await this.getExchangeRates(req.tenant.id);
        exchange_rate = rates[`${currency_from}_${currency_to}`]?.buy;
        
        if (!exchange_rate) {
          return res.status(400).json({
            error: 'Exchange rate not available',
            code: 'RATE_NOT_AVAILABLE'
          });
        }
      }

      // محاسبات مالی
      const amount_to = parseFloat(amount_from) * parseFloat(exchange_rate);
      const commission_settings = await this.getCommissionSettings(tenantDB, 'buy', customer_id);
      const commission_rate = commission_settings.rate || 0.015; // 1.5% default
      const commission = parseFloat(amount_from) * commission_rate;
      const net_amount = amount_to + commission;

      // بررسی موجودی صندوق
      const cashBox = await this.getCashBoxBalance(tenantDB, currency_from);
      if (cashBox.balance < parseFloat(amount_from)) {
        return res.status(400).json({
          error: 'Insufficient cash box balance',
          code: 'INSUFFICIENT_BALANCE',
          available: cashBox.balance,
          required: parseFloat(amount_from)
        });
      }

      // بررسی حد اعتباری مشتری
      const credit_limit = customer.credit_limit || 0;
      const current_balance = customer.current_balance || 0;
      
      if (credit_limit > 0 && (current_balance + net_amount) > credit_limit) {
        return res.status(400).json({
          error: 'Customer credit limit exceeded',
          code: 'CREDIT_LIMIT_EXCEEDED',
          credit_limit,
          current_balance
        });
      }

      // ایجاد تراکنش
      const transaction = {
        reference_id: receipt_number || this.generateReference('BUY'),
        type: 'buy',
        customer_id: new mongoose.Types.ObjectId(customer_id),
        customer_name: customer.name,
        currency_from,
        currency_to,
        amount_from: parseFloat(amount_from),
        amount_to: parseFloat(amount_to),
        exchange_rate: parseFloat(exchange_rate),
        commission: parseFloat(commission),
        commission_rate: parseFloat(commission_rate),
        net_amount: parseFloat(net_amount),
        payment_method,
        notes,
        status: 'completed',
        created_by: req.user.userId,
        created_by_name: req.user.name || 'کاربر سیستم',
        created_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD'),
        metadata: {
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          custom_rate_used: !!custom_rate
        }
      };

      const result = await tenantDB.collection('transactions').insertOne(transaction);
      transaction._id = result.insertedId;

      // به‌روزرسانی موجودی مشتری
      await tenantDB.collection('customers').updateOne(
        { _id: new mongoose.Types.ObjectId(customer_id) },
        { 
          $inc: { 
            current_balance: -net_amount,
            total_transactions: 1,
            total_volume: parseFloat(amount_from)
          },
          $set: { 
            last_transaction: new Date(),
            updated_at: new Date()
          }
        }
      );

      // به‌روزرسانی صندوق
      await this.updateCashBox(tenantDB, currency_from, -parseFloat(amount_from), transaction._id);
      await this.updateCashBox(tenantDB, currency_to, parseFloat(amount_to), transaction._id);

      // ثبت در دفتر حسابداری
      await this.recordAccountingEntry(tenantDB, {
        transaction_id: transaction._id,
        type: 'revenue',
        amount: commission,
        currency: currency_to,
        description: `کارمزد خرید ارز - ${customer.name}`,
        reference_id: transaction.reference_id,
        customer_id: customer_id,
        created_by: req.user.userId
      });

      // ارسال اطلاع‌رسانی
      if (customer.phone) {
        await this.sendTransactionNotification({
          phone: customer.phone,
          type: 'buy',
          amount: amount_from,
          currency: currency_from,
          rate: exchange_rate,
          reference: transaction.reference_id,
          tenant_name: req.tenant.name
        });
      }

      // ارسال به کلاینت‌ها از طریق Socket.IO
      const io = req.app.get('io');
      if (io) {
        io.to(`tenant_${req.tenant.id}`).emit('transaction_created', {
          transaction: transaction,
          type: 'buy'
        });
      }

      logger.info(`Buy transaction created`, {
        tenantId: req.tenant.id,
        transactionId: transaction._id,
        amount: amount_from,
        currency: currency_from,
        customer: customer.name,
        userId: req.user.userId
      });

      res.status(201).json({
        success: true,
        message: 'Buy transaction created successfully',
        data: {
          transaction_id: transaction._id,
          reference_id: transaction.reference_id,
          net_amount: transaction.net_amount,
          commission: transaction.commission,
          customer_balance: current_balance - net_amount
        }
      });

    } catch (error) {
      logger.error('Create buy transaction error:', error);
      res.status(500).json({
        error: 'Failed to create buy transaction',
        code: 'TRANSACTION_CREATE_ERROR',
        message: error.message
      });
    }
  }

  // ایجاد معامله فروش
  async createSellTransaction(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const tenantDB = req.tenant.db;
      const {
        customer_id,
        currency_from,
        currency_to = 'IRR',
        amount_from,
        payment_method = 'cash',
        notes = '',
        custom_rate = null,
        receipt_number = null
      } = req.body;

      // بررسی مشتری
      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(customer_id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      // دریافت نرخ ارز
      let exchange_rate;
      if (custom_rate && req.user.permissions?.includes('rates.custom')) {
        exchange_rate = parseFloat(custom_rate);
      } else {
        const rates = await this.getExchangeRates(req.tenant.id);
        exchange_rate = rates[`${currency_from}_${currency_to}`]?.sell;
        
        if (!exchange_rate) {
          return res.status(400).json({
            error: 'Exchange rate not available',
            code: 'RATE_NOT_AVAILABLE'
          });
        }
      }

      // محاسبات مالی
      const amount_to = parseFloat(amount_from) * parseFloat(exchange_rate);
      const commission_settings = await this.getCommissionSettings(tenantDB, 'sell', customer_id);
      const commission_rate = commission_settings.rate || 0.012; // 1.2% default
      const commission = parseFloat(amount_from) * commission_rate;
      const net_amount = amount_to - commission;

      // بررسی موجودی صندوق
      const cashBox = await this.getCashBoxBalance(tenantDB, currency_to);
      if (cashBox.balance < net_amount) {
        return res.status(400).json({
          error: 'Insufficient cash box balance',
          code: 'INSUFFICIENT_BALANCE',
          available: cashBox.balance,
          required: net_amount
        });
      }

      // ایجاد تراکنش
      const transaction = {
        reference_id: receipt_number || this.generateReference('SELL'),
        type: 'sell',
        customer_id: new mongoose.Types.ObjectId(customer_id),
        customer_name: customer.name,
        currency_from,
        currency_to,
        amount_from: parseFloat(amount_from),
        amount_to: parseFloat(amount_to),
        exchange_rate: parseFloat(exchange_rate),
        commission: parseFloat(commission),
        commission_rate: parseFloat(commission_rate),
        net_amount: parseFloat(net_amount),
        payment_method,
        notes,
        status: 'completed',
        created_by: req.user.userId,
        created_by_name: req.user.name || 'کاربر سیستم',
        created_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD'),
        metadata: {
          ip_address: req.ip,
          user_agent: req.get('User-Agent'),
          custom_rate_used: !!custom_rate
        }
      };

      const result = await tenantDB.collection('transactions').insertOne(transaction);
      transaction._id = result.insertedId;

      // به‌روزرسانی موجودی مشتری
      await tenantDB.collection('customers').updateOne(
        { _id: new mongoose.Types.ObjectId(customer_id) },
        { 
          $inc: { 
            current_balance: net_amount,
            total_transactions: 1,
            total_volume: parseFloat(amount_from)
          },
          $set: { 
            last_transaction: new Date(),
            updated_at: new Date()
          }
        }
      );

      // به‌روزرسانی صندوق
      await this.updateCashBox(tenantDB, currency_from, parseFloat(amount_from), transaction._id);
      await this.updateCashBox(tenantDB, currency_to, -net_amount, transaction._id);

      // ثبت در دفتر حسابداری
      await this.recordAccountingEntry(tenantDB, {
        transaction_id: transaction._id,
        type: 'revenue',
        amount: commission,
        currency: currency_to,
        description: `کارمزد فروش ارز - ${customer.name}`,
        reference_id: transaction.reference_id,
        customer_id: customer_id,
        created_by: req.user.userId
      });

      // ارسال اطلاع‌رسانی
      if (customer.phone) {
        await this.sendTransactionNotification({
          phone: customer.phone,
          type: 'sell',
          amount: amount_from,
          currency: currency_from,
          rate: exchange_rate,
          reference: transaction.reference_id,
          tenant_name: req.tenant.name
        });
      }

      // ارسال به کلاینت‌ها از طریق Socket.IO
      const io = req.app.get('io');
      if (io) {
        io.to(`tenant_${req.tenant.id}`).emit('transaction_created', {
          transaction: transaction,
          type: 'sell'
        });
      }

      logger.info(`Sell transaction created`, {
        tenantId: req.tenant.id,
        transactionId: transaction._id,
        amount: amount_from,
        currency: currency_from,
        customer: customer.name,
        userId: req.user.userId
      });

      res.status(201).json({
        success: true,
        message: 'Sell transaction created successfully',
        data: {
          transaction_id: transaction._id,
          reference_id: transaction.reference_id,
          net_amount: transaction.net_amount,
          commission: transaction.commission,
          customer_balance: (customer.current_balance || 0) + net_amount
        }
      });

    } catch (error) {
      logger.error('Create sell transaction error:', error);
      res.status(500).json({
        error: 'Failed to create sell transaction',
        code: 'TRANSACTION_CREATE_ERROR',
        message: error.message
      });
    }
  }

  // لیست معاملات
  async getTransactions(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        page = 1,
        limit = 20,
        type,
        customer_id,
        currency_from,
        currency_to,
        start_date,
        end_date,
        status = 'completed',
        sort_by = 'created_at',
        sort_order = 'desc'
      } = req.query;

      // ساخت فیلتر
      const filter = { status };
      
      if (type) filter.type = type;
      if (customer_id) filter.customer_id = new mongoose.Types.ObjectId(customer_id);
      if (currency_from) filter.currency_from = currency_from;
      if (currency_to) filter.currency_to = currency_to;

      if (start_date || end_date) {
        filter.created_at = {};
        if (start_date) filter.created_at.$gte = new Date(start_date);
        if (end_date) filter.created_at.$lte = new Date(end_date);
      }

      // تنظیم مرتب‌سازی
      const sortOptions = {};
      sortOptions[sort_by] = sort_order === 'desc' ? -1 : 1;

      // اجرای کوئری
      const skip = (parseInt(page) - 1) * parseInt(limit);
      const transactions = await tenantDB.collection('transactions')
        .find(filter)
        .sort(sortOptions)
        .skip(skip)
        .limit(parseInt(limit))
        .toArray();

      // آمار کلی
      const totalTransactions = await tenantDB.collection('transactions').countDocuments(filter);
      const stats = await tenantDB.collection('transactions').aggregate([
        { $match: filter },
        {
          $group: {
            _id: null,
            total_volume: { $sum: '$amount_from' },
            total_commission: { $sum: '$commission' },
            avg_amount: { $avg: '$amount_from' },
            count: { $sum: 1 }
          }
        }
      ]).toArray();

      res.json({
        success: true,
        data: {
          transactions,
          pagination: {
            page: parseInt(page),
            limit: parseInt(limit),
            total: totalTransactions,
            pages: Math.ceil(totalTransactions / parseInt(limit))
          },
          stats: stats[0] || {
            total_volume: 0,
            total_commission: 0,
            avg_amount: 0,
            count: 0
          }
        }
      });

    } catch (error) {
      logger.error('Get transactions error:', error);
      res.status(500).json({
        error: 'Failed to fetch transactions',
        code: 'TRANSACTIONS_FETCH_ERROR'
      });
    }
  }

  // جزئیات معامله
  async getTransactionById(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { id } = req.params;

      const transaction = await tenantDB.collection('transactions').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!transaction) {
        return res.status(404).json({
          error: 'Transaction not found',
          code: 'TRANSACTION_NOT_FOUND'
        });
      }

      // اطلاعات مشتری
      const customer = await tenantDB.collection('customers').findOne({
        _id: transaction.customer_id
      });

      // سوابق حسابداری
      const accountingEntries = await tenantDB.collection('accounting_entries').find({
        transaction_id: transaction._id
      }).toArray();

      res.json({
        success: true,
        data: {
          transaction,
          customer,
          accounting_entries: accountingEntries
        }
      });

    } catch (error) {
      logger.error('Get transaction by ID error:', error);
      res.status(500).json({
        error: 'Failed to fetch transaction details',
        code: 'TRANSACTION_DETAIL_ERROR'
      });
    }
  }

  // حذف معامله
  async deleteTransaction(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { id } = req.params;

      const transaction = await tenantDB.collection('transactions').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!transaction) {
        return res.status(404).json({
          error: 'Transaction not found',
          code: 'TRANSACTION_NOT_FOUND'
        });
      }

      // فقط ادمین می‌تواند حذف کند
      if (!req.user.permissions?.includes('transactions.delete')) {
        return res.status(403).json({
          error: 'Permission denied',
          code: 'PERMISSION_DENIED'
        });
      }

      // بازگردانی موجودی‌ها
      await this.reverseTransaction(tenantDB, transaction);

      // علامت‌گذاری به عنوان حذف شده
      await tenantDB.collection('transactions').updateOne(
        { _id: transaction._id },
        {
          $set: {
            status: 'cancelled',
            cancelled_by: req.user.userId,
            cancelled_at: new Date(),
            cancel_reason: req.body.reason || 'Manual deletion'
          }
        }
      );

      logger.info(`Transaction cancelled`, {
        tenantId: req.tenant.id,
        transactionId: transaction._id,
        cancelledBy: req.user.userId
      });

      res.json({
        success: true,
        message: 'Transaction cancelled successfully'
      });

    } catch (error) {
      logger.error('Delete transaction error:', error);
      res.status(500).json({
        error: 'Failed to cancel transaction',
        code: 'TRANSACTION_CANCEL_ERROR'
      });
    }
  }

  // Helper methods
  async getCommissionSettings(tenantDB, type, customerId) {
    try {
      const settings = await tenantDB.collection('settings').findOne({
        type: 'commission'
      });

      const defaultRates = {
        buy: 0.015, // 1.5%
        sell: 0.012 // 1.2%
      };

      return {
        rate: settings?.rates?.[type] || defaultRates[type],
        type: 'percentage'
      };
    } catch (error) {
      logger.warn('Failed to get commission settings:', error);
      return { rate: type === 'buy' ? 0.015 : 0.012, type: 'percentage' };
    }
  }

  async getCashBoxBalance(tenantDB, currency) {
    try {
      const cashBox = await tenantDB.collection('cash_box').findOne({
        currency
      });

      return cashBox || { currency, balance: 0 };
    } catch (error) {
      logger.warn('Failed to get cash box balance:', error);
      return { currency, balance: 0 };
    }
  }

  async updateCashBox(tenantDB, currency, amount, transactionId) {
    try {
      await tenantDB.collection('cash_box').updateOne(
        { currency },
        {
          $inc: { balance: amount },
          $set: { updated_at: new Date() },
          $push: {
            transactions: {
              transaction_id: transactionId,
              amount,
              timestamp: new Date()
            }
          }
        },
        { upsert: true }
      );
    } catch (error) {
      logger.error('Failed to update cash box:', error);
      throw error;
    }
  }

  async recordAccountingEntry(tenantDB, entry) {
    try {
      const accountingEntry = {
        ...entry,
        created_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD')
      };

      await tenantDB.collection('accounting_entries').insertOne(accountingEntry);
    } catch (error) {
      logger.warn('Failed to record accounting entry:', error);
    }
  }

  async sendTransactionNotification(data) {
    try {
      // Simplified notification - expand based on your SMS/WhatsApp service
      logger.info('Transaction notification sent', data);
    } catch (error) {
      logger.warn('Failed to send transaction notification:', error);
    }
  }

  async getExchangeRates(tenantId) {
    try {
      // Mock exchange rates - replace with real service
      return {
        'USD_IRR': { buy: 42000, sell: 42500 },
        'EUR_IRR': { buy: 45000, sell: 45600 },
        'GBP_IRR': { buy: 52000, sell: 52700 },
        'AED_IRR': { buy: 11450, sell: 11580 }
      };
    } catch (error) {
      logger.error('Failed to get exchange rates:', error);
      throw error;
    }
  }

  generateReference(type) {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 5);
    return `${type}-${timestamp}-${random}`.toUpperCase();
  }

  async reverseTransaction(tenantDB, transaction) {
    try {
      // بازگردانی موجودی مشتری
      const reverseAmount = transaction.type === 'buy' ? transaction.net_amount : -transaction.net_amount;
      
      await tenantDB.collection('customers').updateOne(
        { _id: transaction.customer_id },
        {
          $inc: {
            current_balance: reverseAmount,
            total_transactions: -1,
            total_volume: -transaction.amount_from
          }
        }
      );

      // بازگردانی صندوق
      if (transaction.type === 'buy') {
        await this.updateCashBox(tenantDB, transaction.currency_from, transaction.amount_from, transaction._id);
        await this.updateCashBox(tenantDB, transaction.currency_to, -transaction.amount_to, transaction._id);
      } else {
        await this.updateCashBox(tenantDB, transaction.currency_from, -transaction.amount_from, transaction._id);
        await this.updateCashBox(tenantDB, transaction.currency_to, transaction.net_amount, transaction._id);
      }
    } catch (error) {
      logger.error('Failed to reverse transaction:', error);
      throw error;
    }
  }
}

module.exports = new TransactionController();