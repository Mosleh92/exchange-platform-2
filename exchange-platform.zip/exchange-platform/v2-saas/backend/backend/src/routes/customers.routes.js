const express = require('express');
const { body, query, param } = require('express-validator');
const CustomerController = require('../controllers/customer.controller');
const tenantIsolation = require('../middleware/tenantIsolation');
const auth = require('../middleware/auth');

const router = express.Router();

router.use(auth);
router.use(tenantIsolation);

const createCustomerValidation = [
  body('name').isString().isLength({ min: 2, max: 100 }).withMessage('Name must be 2-100 characters'),
  body('phone').isMobilePhone('fa-IR').withMessage('Invalid phone number'),
  body('email').optional().isEmail().withMessage('Invalid email address'),
  body('national_id').optional().isString().isLength({ min: 10, max: 10 }).withMessage('National ID must be 10 digits'),
  body('address').optional().isString().isLength({ max: 500 }).withMessage('Address too long'),
  body('credit_limit').optional().isFloat({ min: 0 }).withMessage('Invalid credit limit'),
  body('preferred_currency').optional().isIn(['USD', 'EUR', 'GBP', 'AED', 'IRR']).withMessage('Invalid currency')
];

router.post('/', createCustomerValidation, CustomerController.createCustomer);
router.get('/', CustomerController.getCustomers);
router.get('/:id', param('id').isMongoId(), CustomerController.getCustomerById);
router.put('/:id', param('id').isMongoId(), createCustomerValidation, CustomerController.updateCustomer);
router.delete('/:id', param('id').isMongoId(), CustomerController.deleteCustomer);

// Customer transactions
router.get('/:id/transactions', param('id').isMongoId(), CustomerController.getCustomerTransactions);

// Customer balance operations
router.post('/:id/balance/adjust', [
  param('id').isMongoId(),
  body('amount').isFloat().withMessage('Invalid amount'),
  body('reason').isString().isLength({ min: 5, max: 200 }).withMessage('Reason required'),
  body('type').isIn(['credit', 'debit']).withMessage('Invalid adjustment type')
], CustomerController.adjustCustomerBalance);

module.exports = router;