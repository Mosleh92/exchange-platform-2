const express = require('express');
const { body, query } = require('express-validator');
const AccountingController = require('../controllers/accounting.controller');
const tenantIsolation = require('../middleware/tenantIsolation');
const auth = require('../middleware/auth');

const router = express.Router();

router.use(auth);
router.use(tenantIsolation);

// Reports
router.get('/profit-loss', AccountingController.getProfitLossReport);
router.get('/cash-flow', AccountingController.getCashFlowReport);
router.get('/balance-sheet', AccountingController.getBalanceSheet);
router.get('/daily-summary', AccountingController.getDailySummary);

// Entries
router.post('/expense', [
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount required'),
  body('category').isString().isLength({ min: 2, max: 50 }).withMessage('Category required'),
  body('description').isString().isLength({ min: 5, max: 200 }).withMessage('Description required'),
  body('currency').optional().isIn(['USD', 'EUR', 'GBP', 'AED', 'IRR']).withMessage('Invalid currency')
], AccountingController.recordExpense);

router.post('/revenue', [
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount required'),
  body('category').isString().isLength({ min: 2, max: 50 }).withMessage('Category required'),
  body('description').isString().isLength({ min: 5, max: 200 }).withMessage('Description required'),
  body('currency').optional().isIn(['USD', 'EUR', 'GBP', 'AED', 'IRR']).withMessage('Invalid currency')
], AccountingController.recordRevenue);

// Export
router.get('/export/excel', AccountingController.exportToExcel);
router.get('/export/pdf', AccountingController.exportToPDF);

module.exports = router;