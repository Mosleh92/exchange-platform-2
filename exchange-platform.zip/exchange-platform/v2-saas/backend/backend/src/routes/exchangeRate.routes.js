const express = require('express');
const { body } = require('express-validator');
const ExchangeRateController = require('../controllers/exchangeRate.controller');
const tenantIsolation = require('../middleware/tenantIsolation');
const auth = require('../middleware/auth');

const router = express.Router();

router.use(auth);
router.use(tenantIsolation);

// Get current rates
router.get('/', ExchangeRateController.getCurrentRates);
router.get('/history', ExchangeRateController.getRateHistory);

// Update rates (admin only)
router.put('/', [
  body('rates').isObject().withMessage('Rates object required'),
  body('rates.*.buy').optional().isFloat({ min: 0 }).withMessage('Invalid buy rate'),
  body('rates.*.sell').optional().isFloat({ min: 0 }).withMessage('Invalid sell rate')
], ExchangeRateController.updateRates);

// Rate alerts
router.post('/alerts', [
  body('currency_pair').isString().withMessage('Currency pair required'),
  body('threshold').isFloat({ min: 0 }).withMessage('Threshold required'),
  body('type').isIn(['above', 'below']).withMessage('Invalid alert type')
], ExchangeRateController.createRateAlert);

module.exports = router;